# PlayRtttl
Plays RTTTL melodies/ringtones from FLASH or RAM. Provides a non blocking version and a name output function.
Includes 21 sample melodies.

## Download
The actual version can be downloaded directly from GitHub [here] (https://github.com/ArminJo/PlayRtttl/blob/master/extras/PlayRtttl.zip?raw=true)

# Installation
Download PlayRtttl.zip file or use the GitHub *clone or download -> Download ZIP* button, and add the .zip file with *Sketch -> Include Library -> add .ZIP Library...*.  